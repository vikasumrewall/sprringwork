package com.springcore.noxml;

import org.springframework.stereotype.Component;

@Component
public class Samosa {
	
	public void enjoy()
	{
		System.out.println("i am enjoying samosa");
		
	}

}
