package com.springcore.noxml.beanannotation;

public class Samosa {
	
	public void enjoy()
	{
		System.out.println("i am enjoying samosa");
		
	}

}
